# seqpac
Group based analysis of small RNA sequencing data
