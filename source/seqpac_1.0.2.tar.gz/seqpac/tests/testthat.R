library(testthat)
library(seqpac)

test_check("seqpac")
