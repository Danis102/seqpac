# seqpac
Seqpac: A Framework for small RNA analysis in R using Sequence-Based Counts
